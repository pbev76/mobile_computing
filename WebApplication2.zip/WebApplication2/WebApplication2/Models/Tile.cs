﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApplication2.Models
{
    public class Tile
    {
        public int ID { get; set; }
        public int HWID { get; set; }
        public int UUID { get; set; }
    }
}