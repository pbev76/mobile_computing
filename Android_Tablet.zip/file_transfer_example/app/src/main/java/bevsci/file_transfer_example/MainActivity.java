package bevsci.file_transfer_example;

import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.Console;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;


import android.app.Activity;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import static java.security.AccessController.getContext;

public class MainActivity extends Activity implements OnClickListener {
    String new_url = "http://192.168.0.101:80/api/patient/";
    String strURL = "http://192.168.0.101:80/api/patient";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        findViewById(R.id.get_all_patients_button).setOnClickListener(this);
        findViewById(R.id.refresh_button).setOnClickListener(this);
    }


    @Override
    public void onClick(View arg0) {
        switch(arg0.getId()){
            case R.id.get_all_patients_button:
                Button b = (Button)findViewById(R.id.get_all_patients_button);
                new LongRunningGetIO().execute(strURL);
            case R.id.refresh_button:
                if(new_url == "http://192.168.0.101:80/api/patient/") {
                    Button refresh = (Button) findViewById(R.id.refresh_button);
                    new LongRunningGetIO().execute(new_url);
                }/*
                else {
                    Button refresh = (Button) findViewById(R.id.refresh_button);
                    refresh.setClickable(true);
                }
            case R.id.spinner:
                if(new_url != "http://192.168.0.101:80/api/patient/")
                    new LongRunningGetIO().execute(strURL);
                else
                    new LongRunningGetIO().execute(new_url);*/
        }
    }


    private class LongRunningGetIO extends AsyncTask <String, Void, String> {


        private String readStream(InputStream is) {
            try {
                ByteArrayOutputStream bo = new ByteArrayOutputStream();
                int i = is.read();
                while(i != -1) {
                    bo.write(i);
                    i = is.read();
                }
                return bo.toString();
            } catch (IOException e) {
                return "";
            }
        }
        @Override
        protected String doInBackground(String... params) {
            String text = "";

            HttpURLConnection urlConnection = null;
            try {
                URL url = new URL(params[0]);
                urlConnection = (HttpURLConnection) url.openConnection();
                urlConnection = (HttpURLConnection) url.openConnection();
                InputStream in = new BufferedInputStream(urlConnection.getInputStream());
                text = readStream(in);
                in.close();
            }
            catch (Exception exception)
            {

            }
            finally {
                urlConnection.disconnect();
            }


            return text;
        }
        List<String> patients;
        JSONArray text_json;
        protected void onPostExecute(String results) {
            if (results!=null) {
                patients = new ArrayList<String>();
                try
                {
                    text_json = new JSONArray(results);
                    for(int i = 0; i < text_json.length(); i++)
                    {
                        JSONObject jObj = text_json.getJSONObject(i);
                        patients.add(jObj.getString("name"));
                    }
                }
                catch(JSONException ex)
                {
                    ex.printStackTrace();
                }
                EditText et = (EditText)findViewById(R.id.my_edit);
                final EditText history = (EditText)findViewById(R.id.history);
                final EditText name = (EditText)findViewById(R.id.name);
                final EditText sex = (EditText)findViewById(R.id.sex);
                final EditText height = (EditText)findViewById(R.id.height);
                final EditText weight = (EditText)findViewById(R.id.weight);
                final EditText age = (EditText)findViewById(R.id.age);
                final EditText bp_high = (EditText)findViewById(R.id.BP_High);
                final EditText bp_low = (EditText)findViewById(R.id.BP_Low);
                final EditText pulse = (EditText)findViewById(R.id.Pulse_Rate);
                final EditText o2_sat = (EditText)findViewById(R.id.O2Sat);
                ArrayAdapter adp1 = new ArrayAdapter(getApplicationContext(), R.layout.support_simple_spinner_dropdown_item, patients);
                Spinner sp1 = (Spinner)findViewById(R.id.spinner);
                sp1.setAdapter(adp1);sp1.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                    public void onItemSelected(AdapterView<?> arg0, View arg1,
                                               int arg2, long arg3) {
                        // TODO Auto-generated method stub
                        Toast.makeText(getApplicationContext(), patients.get(arg2),Toast.LENGTH_SHORT).show();
                        String name_of_patient = patients.get(arg2);
                        for(int i = 0; i < text_json.length(); i++)
                        {
                            try{
                                JSONObject jObj = text_json.getJSONObject(i);
                                if (jObj.getString("name").equals(name_of_patient)) {
                                    new_url = new_url + jObj.getString("id");
                                    history.setText("History: " + jObj.getString("history"));
                                    name.setText("Name: " + jObj.getString("name"));
                                    sex.setText("Sex: " + jObj.getString("sex"));
                                    height.setText("Height: " + jObj.getString("height"));
                                    weight.setText("Weight: " + jObj.getString("weight"));
                                    age.setText("Age: " + jObj.getString("age"));
                                    bp_high.setText("BP(High): " + jObj.getString("BP_High"));
                                    bp_low.setText("BP(Low): " + jObj.getString("BP_Low"));
                                    pulse.setText("Pulse " + jObj.getString("Pulse"));
                                    o2_sat.setText("Blood O2 Level: " + jObj.getString("O2Sat"));
                                }
                            }
                            catch (JSONException ex){
                                ex.printStackTrace();
                            }
                        }
                    }
                    public void onNothingSelected(AdapterView<?> arg0) {
                        // TODO Auto-generated method stub
                    }
                });
                et.setText(results);
            }


            Button b = (Button)findViewById(R.id.get_all_patients_button);
            Button refresh = (Button)findViewById(R.id.refresh_button);

            b.setClickable(true);
            refresh.setClickable(true);
        }


    }

}

